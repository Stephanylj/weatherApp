//
//  Weather.swift
//  weatherApp
//
//  Created by sala209 equipo1 on 26/01/18.
//  Copyright © 2018 sala209 equipo1. All rights reserved.
//

import Foundation

class Weather{
    
    let temperature: Int?
    let humidity: Int?
    let rain: Int?
    let summary: String?
    let icon: String?
    
    struct WeatherKeys{
        static let temperature = "temperature"
        static let humidity = "humidity"
        static let rain = "precipProbability"
        static let summary = "summary"
        static let icon = "icon"
    }
    
    init(weatherDictionary: [String : Any]){
        temperature = weatherDictionary[WeatherKeys.temperature] as? Int
        
        if let humidityDouble = weatherDictionary[WeatherKeys.humidity] as? Double {
            humidity = Int(humidityDouble*100)
        } else {
            humidity = nil
        }
        
        if let rainDouble = weatherDictionary[WeatherKeys.rain] as? Double {
            rain = Int(rainDouble*100)
        } else {
            rain = nil
        }
        
        summary = weatherDictionary[WeatherKeys.summary] as? String
        
        icon = weatherDictionary[WeatherKeys.icon] as? String

    }
}
