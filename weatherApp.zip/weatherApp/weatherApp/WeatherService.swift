//
//  weatherService.swift
//  weatherApp
//
//  Created by sala209 equipo1 on 26/01/18.
//  Copyright © 2018 sala209 equipo1. All rights reserved.
//

import Foundation

class WeatherService{

    let serviceAPIKey: String
    let baseURL: URL?
    
    init(APIKey: String){
        self.serviceAPIKey = APIKey
        baseURL = URL(string: "https://api.darksky.net/forecast/\(APIKey)")
    }
    
    func getCurrentWeather(latitude: Double, longitude: Double, completion: @escaping (Weather?) -> Void){
        if let serviceURL = URL(string: "\(baseURL!)/\(latitude),\(longitude)", relativeTo: baseURL!){
            let network = Network(url: serviceURL)
            network.downloadJSONFromURL({ (jsonDictionary) in
                if let weatherDictionary = jsonDictionary?["currently"] as? [String : Any]{
                    let weather = Weather(weatherDictionary: weatherDictionary)
                    completion(weather)
                }else{
                    completion(nil)
                }
            })
        }
    }
}
