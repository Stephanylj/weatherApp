//
//  ViewController.swift
//  weatherApp
//
//  Created by sala209 equipo1 on 26/01/18.
//  Copyright © 2018 sala209 equipo1. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

