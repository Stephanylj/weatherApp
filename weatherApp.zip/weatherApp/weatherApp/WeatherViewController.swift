//
//  WeatherViewController.swift
//  weatherApp
//
//  Created by sala209 equipo1 on 26/01/18.
//  Copyright © 2018 sala209 equipo1. All rights reserved.
//

import UIKit
import CoreLocation

class WeatherViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var temperatureLabel: UILabel!
    @IBOutlet weak var humidityLabel: UILabel!
    @IBOutlet weak var rainLabel: UILabel!
    @IBOutlet weak var summaryLabel: UILabel!
    @IBAction func refresh(_ sender: AnyObject) {
        locationManager.startUpdatingLocation()
    }
    
    var locationManager: CLLocationManager = CLLocationManager()
    var startLocation: CLLocation!

    let serviceAPIKey = "ea76e78f539ef7dae1879fd1a45d3628"
    var latitude: Double = 42.3601
    var longitude: Double = -71.0589
    var weatherService: WeatherService!

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let locValue:CLLocationCoordinate2D = manager.location!.coordinate
        latitude = locValue.latitude
        longitude = locValue.longitude
        
        let location = CLLocation(latitude: latitude, longitude: longitude)
        
        fetchCountryAndCity(location: location) { country, city in
            print("country:", country)
            print("city:", city)
            self.locationLabel.text = city
            self.cityLabel.text = country
        }
        
        let weatherService = WeatherService(APIKey: serviceAPIKey)
        weatherService.getCurrentWeather(latitude: latitude, longitude: longitude) { (currentWeather) in
            if let currentWeather = currentWeather {
                DispatchQueue.main.async {
                    if let temperature = currentWeather.temperature {
                        self.temperatureLabel.text = "\(temperature)"
                    } else {
                        self.temperatureLabel.text = "-"
                    }
                    if let humidity = currentWeather.humidity {
                        self.humidityLabel.text = "\(humidity)"
                    } else {
                        self.humidityLabel.text = "-"
                    }
                    if let rain = currentWeather.rain {
                        self.rainLabel.text = "\(rain)"
                    } else {
                        self.rainLabel.text = "-"
                    }
                }
            }
        }
        
        locationManager.stopUpdatingLocation()
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        startLocation = nil
        
        
    }

    
    func fetchCountryAndCity(location: CLLocation, completion: @escaping (String, String) -> ()) {
        CLGeocoder().reverseGeocodeLocation(location) { placemarks, error in
            if let error = error {
                print(error)
            } else if let country = placemarks?.first?.country,
                let city = placemarks?.first?.locality {
                completion(country, city)
            }
        }
    }
}
